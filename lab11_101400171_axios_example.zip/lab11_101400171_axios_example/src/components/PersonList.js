import React, { Component } from 'react';
import axios from 'axios';

class PersonList extends Component {
    state = {
        persons: []
    };

    //Component Lifecycle Callback
    componentDidMount() {
        axios.get(`https://randomuser.me/api/?results=10`)
        .then(res => {
            console.log(res.data);
            const persons = res.data.results;
            this.setState({ persons });
        })
        .catch(error => {
            console.error("You have gotten an error!", error);
        });
    }

    render() {
        return (
          <div>
            <h2>Person List</h2>            
              {this.state.persons.map(person => (
                <p key={person.login.uuid}>
                  {person.name.first} {person.name.last}
                </p>
              ))}
          </div>
        );
      }
    }
    
    export default PersonList;
